// Captura o formulário e a área onde a resposta será exibida.
const formulario = document.getElementById("form-cadastro");
const resultado = document.getElementById("resultado");

// Executa esta função quando a pessoa envia o formulário.
formulario.addEventListener("submit", function(event) {
    // Impede o recarregamento da página para mostrar o resultado aqui mesmo.
    event.preventDefault();

    // Lê os valores digitados nos campos.
    const nome = document.getElementById("nome").value.trim();
    const situacao = document.getElementById("situacao").value;
    const area = document.getElementById("area").value.trim();

    // Variável que guardará a recomendação inicial.
    let sugestao = "";

    // Regra de negócio: a recomendação muda conforme a situação selecionada.
    if (situacao === "estudante") {
        sugestao = "Procure oportunidades de estágio, projetos acadêmicos e cursos ligados à área escolhida.";
    } else if (situacao === "buscando") {
        sugestao = "Prepare um currículo de uma página e pesquise vagas de entrada, jovem aprendiz e funções iniciais.";
    } else if (situacao === "mudanca") {
        sugestao = "Escolha uma habilidade importante para a nova área e faça um curso introdutório antes de se candidatar.";
    } else {
        sugestao = "Comece organizando suas habilidades e pesquisando oportunidades para iniciantes.";
    }

    // Template literal monta uma mensagem usando os dados preenchidos.
    // innerHTML atualiza a página sem precisar abrir outra tela.
    resultado.innerHTML = `
        <h3>Seu próximo passo, ${nome}!</h3>
        <p>Para começar na área de <strong>${area}</strong>, nossa sugestão é: ${sugestao}</p>
        <p><strong>Dica:</strong> confira sempre os requisitos e use sites oficiais para se candidatar.</p>
    `;

    // Mostra a caixa de resultado depois do envio.
    resultado.classList.add("visivel");
});

// Ao limpar o formulário, a mensagem antiga também desaparece.
formulario.addEventListener("reset", function() {
    resultado.innerHTML = "";
    resultado.classList.remove("visivel");
});
